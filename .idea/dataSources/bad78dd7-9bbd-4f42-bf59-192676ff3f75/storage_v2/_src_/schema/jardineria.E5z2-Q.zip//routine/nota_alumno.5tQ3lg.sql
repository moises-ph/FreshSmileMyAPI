create
    definer = root@localhost procedure nota_alumno(IN nota int, OUT mensaje varchar(100))
BEGIN
  IF nota >= 0 AND nota <= 5 THEN
    SET mensaje = 'La nota del alumno es: Insuficiente';
  ELSEIF nota > 5 AND nota <= 6 THEN
    SET mensaje = 'La nota del alumno es: Aprobado';
  ELSEIF nota > 6 AND nota <= 7 THEN
    SET mensaje = 'La nota del alumno es: Bien';
  ELSEIF nota > 7 AND nota <= 9 THEN
    SET mensaje = 'La nota del alumno es: Notable';
  ELSEIF nota > 9 AND nota <= 10 THEN
    SET mensaje = 'La nota del alumno es: Sobresaliente';
  ELSE
   SET mensaje = "En cualquier otro caso la nota no será válida";
  END IF;
END;

