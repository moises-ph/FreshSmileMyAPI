create
    definer = root@localhost procedure verificar_nota(IN nota double, OUT nota_alumno varchar(20))
BEGIN
   CASE
     WHEN nota >= 0 AND nota < 5 THEN
       SET nota_alumno = 'insuficiente';
     WHEN nota >= 5 AND nota < 6 THEN
       SET nota_alumno = 'aprobado';
     WHEN nota >= 6 AND nota < 7 THEN
       SET nota_alumno = 'bien';
     WHEN nota >= 7 AND nota < 9 THEN
       SET nota_alumno = 'notable';
     WHEN nota >= 9 AND nota < 10 THEN
       SET nota_alumno = 'sobresaliente';
     ELSE
       SET nota_alumno = 'nota no valida';
     END CASE;
 END;

