create
    definer = root@localhost procedure positivo_negativo(IN numero float, OUT mesaje varchar(200))
BEGIN
-- la palabra clave THEN se utiliza para indicar el inicio del bloque de código que se ejecutará --
     IF numero > 0 THEN
    SET mesaje = 'El número es positivo';
  ELSEIF numero < 0 THEN
    SET mesaje = 'El número es negativo';
  ELSE
    SET mesaje = 'El número es cero';
  END IF;
END;

