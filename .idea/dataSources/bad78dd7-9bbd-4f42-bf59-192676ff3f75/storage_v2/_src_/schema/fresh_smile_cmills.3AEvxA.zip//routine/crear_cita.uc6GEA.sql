create
    definer = root@localhost procedure crear_cita(IN p_numero_documento int, IN p_nombre_completo varchar(400),
                                                  IN p_tipo_documento varchar(100), IN p_fecha date, IN p_hora time,
                                                  IN p_id_paciente int, IN p_id_especialista int,
                                                  IN p_id_procedimiento int,
                                                  IN p_estado_cita enum ('Confirmada', 'Realizada', 'Cancelada'))
BEGIN
INSERT INTO citas(numero_documento, nombre_completo, tipo_documento, fecha, hora, id_paciente, id_especialista, id_procedimiento, estado_cita)
VALUES(p_numero_documento, p_nombre_completo, p_tipo_documento, p_fecha, p_hora, p_id_paciente, p_id_especialista, p_id_procedimiento, p_estado_cita);
END;

