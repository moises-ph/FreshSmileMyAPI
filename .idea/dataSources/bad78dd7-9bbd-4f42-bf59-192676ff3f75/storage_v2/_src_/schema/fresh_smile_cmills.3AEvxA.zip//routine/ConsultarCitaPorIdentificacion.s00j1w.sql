create
    definer = root@localhost procedure ConsultarCitaPorIdentificacion(IN p_identificacion int)
BEGIN
SELECT * FROM citas WHERE identificacion_citas = p_identificacion;
END;

