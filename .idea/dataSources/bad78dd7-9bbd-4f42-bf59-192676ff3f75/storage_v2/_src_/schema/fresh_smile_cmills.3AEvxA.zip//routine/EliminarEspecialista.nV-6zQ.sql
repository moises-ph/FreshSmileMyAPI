create
    definer = root@localhost procedure EliminarEspecialista(IN p_identificacion int)
BEGIN
DELETE FROM especialista WHERE identificacion_especialista = p_identificacion;
SELECT 'Especialista eliminado exitosamente.' AS Mensaje;
END;

