create
    definer = root@localhost procedure eliminarCodigoAdministrador(IN p_codigo varchar(10))
BEGIN
DELETE FROM Codigo_Administrador
WHERE codigo = p_codigo;
END;

