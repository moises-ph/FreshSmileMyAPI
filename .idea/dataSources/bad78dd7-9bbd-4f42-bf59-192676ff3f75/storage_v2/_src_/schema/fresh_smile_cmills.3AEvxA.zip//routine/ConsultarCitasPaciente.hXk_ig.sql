create
    definer = root@localhost procedure ConsultarCitasPaciente(IN p_id_paciente int)
BEGIN
SELECT * FROM citas
WHERE id_paciente = p_id_paciente;
END;

