create
    definer = root@localhost procedure ModificarProcedimiento(IN p_identificacion int, IN p_nombre varchar(100),
                                                              IN p_descripcion varchar(200), IN p_costo decimal(10, 3))
BEGIN
UPDATE procedimientos
SET nombre = p_nombre, descripcion = p_descripcion, costo = p_costo
WHERE identificacion_procedimientos = p_identificacion;
SELECT 'Procedimiento modificado exitosamente.' AS Mensaje;
END;

