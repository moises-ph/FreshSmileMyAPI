create
    definer = root@localhost procedure ConsultarPacientePorIdentificacion(IN p_identificacion int)
BEGIN
SELECT * FROM paciente WHERE identificacion_paciente = p_identificacion;
END;

