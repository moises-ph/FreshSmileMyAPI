create
    definer = root@localhost procedure ConsultarProcedimientoPorIdentificacion(IN p_identificacion int)
BEGIN
SELECT * FROM procedimientos WHERE identificacion_procedimientos = p_identificacion;
END;

