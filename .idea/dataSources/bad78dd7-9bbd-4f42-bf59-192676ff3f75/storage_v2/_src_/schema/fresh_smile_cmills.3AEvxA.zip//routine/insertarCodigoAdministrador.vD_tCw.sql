create
    definer = root@localhost procedure insertarCodigoAdministrador(IN p_codigo varchar(10))
BEGIN
INSERT INTO Codigo_Administrador (codigo)
VALUES (p_codigo);
END;

