create
    definer = root@localhost procedure ModificarPaciente(IN p_identificacion int, IN p_tipo_documento varchar(40),
                                                         IN p_nombre_completo varchar(400), IN p_telefono varchar(20),
                                                         IN p_direccion varchar(100), IN p_correo varchar(100),
                                                         IN p_contraseña varchar(8))
BEGIN
UPDATE paciente
SET tipo_documento = p_tipo_documento, nombre_completo = p_nombre_completo, telefono = p_telefono,
    direccion = p_direccion, correo = p_correo, contraseña = p_contraseña
WHERE identificacion_paciente = p_identificacion;
SELECT 'Paciente modificado exitosamente.' AS Mensaje;
END;

