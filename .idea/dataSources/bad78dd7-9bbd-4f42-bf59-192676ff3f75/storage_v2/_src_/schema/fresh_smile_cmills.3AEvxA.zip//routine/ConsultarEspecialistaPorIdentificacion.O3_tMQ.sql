create
    definer = root@localhost procedure ConsultarEspecialistaPorIdentificacion(IN p_identificacion int)
BEGIN
SELECT * FROM especialista WHERE identificacion_especialista = p_identificacion;
END;

