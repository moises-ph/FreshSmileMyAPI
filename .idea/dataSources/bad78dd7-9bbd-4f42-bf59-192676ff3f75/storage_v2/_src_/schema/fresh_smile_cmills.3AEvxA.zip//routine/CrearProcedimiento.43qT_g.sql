create
    definer = root@localhost procedure CrearProcedimiento(IN p_nombre varchar(100), IN p_descripcion varchar(200),
                                                          IN p_costo decimal(10, 3))
BEGIN
INSERT INTO procedimientos (nombre, descripcion, costo)
VALUES (p_nombre, p_descripcion, p_costo);
SELECT 'Procedimiento creado exitosamente.' AS Mensaje;
END;

