create
    definer = root@localhost procedure ModificarEspecialista(IN p_identificacion int, IN p_tipo_documento varchar(40),
                                                             IN p_nombre_completo varchar(100),
                                                             IN p_telefono varchar(20), IN p_direccion varchar(100),
                                                             IN p_especialidad varchar(50),
                                                             IN p_descripcion varchar(200), IN p_foto_perfil blob,
                                                             IN p_correo varchar(100), IN p_contraseña varchar(100))
BEGIN
UPDATE especialista
SET tipo_documento = p_tipo_documento, nombre_completo = p_nombre_completo, telefono = p_telefono,
    direccion = p_direccion, especialidad = p_especialidad, descripcion = p_descripcion,
    foto_perfil = p_foto_perfil, correo = p_correo, contraseña = p_contraseña
WHERE identificacion_especialista = p_identificacion;
SELECT 'Especialista modificado exitosamente.' AS Mensaje;
END;

