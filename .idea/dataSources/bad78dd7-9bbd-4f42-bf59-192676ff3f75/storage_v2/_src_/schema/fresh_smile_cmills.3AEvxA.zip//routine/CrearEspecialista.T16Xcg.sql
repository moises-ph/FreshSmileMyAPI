create
    definer = root@localhost procedure CrearEspecialista(IN p_identificacion int, IN p_tipo_documento varchar(40),
                                                         IN p_nombre_completo varchar(100), IN p_telefono varchar(20),
                                                         IN p_direccion varchar(100), IN p_especialidad varchar(50),
                                                         IN p_descripcion varchar(200), IN p_foto_perfil blob,
                                                         IN p_correo varchar(100), IN p_contraseña varchar(100))
BEGIN
INSERT INTO especialista (identificacion_especialista, tipo_documento, nombre_completo, telefono, direccion, especialidad, descripcion, foto_perfil, correo, contraseña)
VALUES (p_identificacion, p_tipo_documento, p_nombre_completo, p_telefono, p_direccion, p_especialidad, p_descripcion, p_foto_perfil, p_correo, p_contraseña);
SELECT 'Especialista creado exitosamente.' AS Mensaje;
END;

