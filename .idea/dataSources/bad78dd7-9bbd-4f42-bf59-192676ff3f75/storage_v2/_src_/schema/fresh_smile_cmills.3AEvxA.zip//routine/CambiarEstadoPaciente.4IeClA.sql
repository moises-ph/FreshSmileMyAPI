create
    definer = root@localhost procedure CambiarEstadoPaciente(IN p_identificacion int, IN new_estado bit)
BEGIN
UPDATE paciente set estado = new_estado where identificacion_paciente = p_identificacion;
Select "Estado del paciente cambiado correctamente" as Message;
END;

