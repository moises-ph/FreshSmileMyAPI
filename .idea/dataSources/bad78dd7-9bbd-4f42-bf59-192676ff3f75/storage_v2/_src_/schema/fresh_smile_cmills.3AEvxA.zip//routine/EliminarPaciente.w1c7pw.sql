create
    definer = root@localhost procedure EliminarPaciente(IN p_identificacion int)
BEGIN
DELETE FROM paciente WHERE identificacion_paciente = p_identificacion;
SELECT 'Paciente eliminado exitosamente.' AS Mensaje;
END;

