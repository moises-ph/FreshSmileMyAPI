create
    definer = root@localhost procedure ConsultarCitasRangoFechas(IN p_fecha_inicio date, IN p_fecha_fin date)
BEGIN
SELECT *
FROM citas
WHERE fecha BETWEEN p_fecha_inicio AND p_fecha_fin;
END;

