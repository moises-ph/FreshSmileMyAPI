create
    definer = root@localhost procedure EliminarCita(IN p_identificacion int)
BEGIN
DELETE FROM citas WHERE identificacion_citas = p_identificacion;
SELECT 'Cita eliminada exitosamente.' AS Mensaje;
END;

