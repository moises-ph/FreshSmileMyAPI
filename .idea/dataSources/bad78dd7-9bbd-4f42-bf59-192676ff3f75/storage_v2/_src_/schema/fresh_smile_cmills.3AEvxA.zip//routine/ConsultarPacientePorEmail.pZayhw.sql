create
    definer = root@localhost procedure ConsultarPacientePorEmail(IN p_correo varchar(100))
BEGIN
    SELECT * FROM paciente WHERE correo = p_correo;
END;

