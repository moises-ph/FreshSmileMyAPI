create
    definer = root@localhost procedure EliminarProcedimiento(IN p_identificacion int)
BEGIN
DELETE FROM procedimientos WHERE identificacion_procedimientos = p_identificacion;
SELECT 'Procedimiento eliminado exitosamente.' AS Mensaje;
END;

