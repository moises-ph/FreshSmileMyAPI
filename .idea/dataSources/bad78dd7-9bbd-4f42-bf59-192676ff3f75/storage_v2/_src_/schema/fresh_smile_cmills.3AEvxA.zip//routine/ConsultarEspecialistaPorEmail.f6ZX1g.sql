create
    definer = root@localhost procedure ConsultarEspecialistaPorEmail(IN p_correo varchar(100))
BEGIN
    SELECT * FROM especialista WHERE correo = p_correo;
END;

