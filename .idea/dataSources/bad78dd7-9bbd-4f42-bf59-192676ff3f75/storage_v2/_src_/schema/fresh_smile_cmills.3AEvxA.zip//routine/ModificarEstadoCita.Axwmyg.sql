create
    definer = root@localhost procedure ModificarEstadoCita(IN p_id_cita int,
                                                           IN p_estado_cita enum ('Confirmada', 'Realizada', 'Cancelada'))
BEGIN
UPDATE citas
SET estado_cita = p_estado_cita
WHERE identificacion_citas = p_id_cita;
END;

