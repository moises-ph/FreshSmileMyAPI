create
    definer = root@localhost procedure consultarCodigoAdmin()
begin
SELECT * from Codigo_Administrador;
end;

