create
    definer = root@localhost procedure ConsultarCitasFecha(IN p_fecha date)
BEGIN
SELECT *
FROM citas
WHERE fecha = p_fecha;
END;

